# Cobra Sentinel by SilentCobra

نسخة Cobra Sentinel من تعديل SilentCobra، مبنية على [RFSentinel](https://github.com/CIS-C0/RFSentinel) (رخصة GPL-3.0).

## الخطوات
1. أنشئ مستودعاً جديداً على GitHub (Public).
2. ارفع محتويات هذا الـ ZIP كما هي (مجلد `.github` + `README.md`).
3. (اختياري) نزّل كود المصدر من المستودع الأصلي: Code ← Download ZIP، وغيّر اسمه إلى `source.zip` وارفعه في جذر المستودع.
   بعد تعديلك على الكود أعد ضغطه بنفس الاسم. إن لم تضعه، سيحمّل الـ workflow الكود الأصلي تلقائياً.
4. أضف مفتاح التوقيع (مرة واحدة، لتعمل التحديثات): Settings ← Secrets and variables ← Actions:
   - `KEYSTORE_BASE64` : ناتج `base64 -w0 my.jks`
   - `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
5. تبويب Actions ← "Build Cobra Sentinel APK" ← Run workflow (اكتب Tag مثل v1.0.0).
6. ستجد ملف APK في تبويب Releases.

## إنشاء مفتاح توقيع
    keytool -genkeypair -v -keystore my.jks -alias rfsentinel -keyalg RSA -keysize 4096 -validity 10000

## الترخيص
GPL-3.0: يجب إبقاء ملف LICENSE وإشعارات حقوق النشر الأصلية، وذكر تعديلاتك،
ونشر الكود المصدري لأي نسخة معدّلة توزعها.

## تغيير الاسم
الاسم والمعرّف في أعلى خطوة "Apply SilentCobra branding" داخل ملف الـ workflow (`NEW_NAME` و`NEW_ID`).
التغيير يتم أثناء البناء، فيظهر الاسم الجديد داخل ملف APK الناتج.
